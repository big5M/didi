$(function(){
    var h3=$('#pages0 .inner h3');
    var car =$('#pages0 .inner .car img');
    // var imgSrc=[];
    var imgSrc = ["img/light.png","img/load-car.png"];
    // for(var i=1;i<imgSrc.;i++){
    //     imgSrc.push('imgs/chip'+i+'.png');
    // }
    var loaded=0;
    var timer;
    var toload = imgSrc.length;
    for(var i=0;i<imgSrc.length;i++){
    var img = new Image();
    img.onload = function(){
        loaded++;
        var percent = loaded / toload ;
        h3.html(percent*100+'%');
        car.css({
            '-webkit-animation': "runningCar .5s linear",
        })
        if (percent == 1) {
            var timer;
            timer = setTimeout(function () {
            $('#pages0').hide();
            $('#pages1').show();
        }, 1000)
        }
    }
            img.src = imgSrc[i];
    }
    var start=$('#pages1 .inner .sec5 img').click(function(){
        $('#pages1').hide();
        $('#pages2').show();
    })
    var success = [
      "桃花运加持,<br>这就把纯洁的拼车友谊<br>升华一下~",
      "2016年必须知道的<br>七大定律之一:<br>拼车一口价,车费不变定律",
      "你们要的虐狗套餐,<br>拼车相当于<br>两人同行一人免单!<br>上限两人哦~",
      "老板发的红包太小,<br>买不起汉堡......<br>快车我还坐得起哒~",
      "新年出门不怕堵,<br>这有一百种捷径让所有路线<br>都顺理成章!"
  ];
  var fail = [
      "单身怪我咯?<br>不拼哪来的爱情!",
      "这都不造哎,<br>注定一辈子吃土!",
      "除了基友,<br>你木有盆友了咩?",
      "歪!脚气很重么朋友!",
      "想象力已突破天际,<br>还是甩不掉路痴的命"
  ];

    var arr1=["imgs/word1.png","imgs/word2.png","imgs/word3.png","imgs/word4.png","imgs/word5.png","imgs/word6.png","imgs/word7.png","imgs/word8.png"];
    var arr2=["imgs/word9.png","imgs/word10.png","imgs/word11.png","imgs/word12.png","imgs/word13.png","imgs/word14.png","imgs/word15.png","imgs/word16.png"];
    var arr3=["imgs/word17.png","imgs/word18.png","imgs/word19.png","imgs/word20.png","imgs/word21.png","imgs/word22.png","imgs/word23.png","imgs/word24.png"];
    var arr4=["imgs/word25.png","imgs/word26.png","imgs/word27.png","imgs/word28.png","imgs/word29.png","imgs/word30.png","imgs/word31.png","imgs/word32.png"];
    var arr5=["imgs/word33.png","imgs/word34.png","imgs/word35.png","imgs/word36.png","imgs/word37.png","imgs/word38.png","imgs/word39.png","imgs/word40.png"];
    var array=[arr1,arr2,arr3,arr4,arr5];
    var sps=$('#pages2 .inner .p3-img span');

    var zhq1=["47","107","417","0672","4630"];
    var gnum=0;
    var score=0;
    function show(){
        nextg(gnum);
        var str='';
        var a=0;
        sps.unbind('click');
        sps.on('click',function(){

            str+=$(this).index()-1;
            $('#pages2 .inner .p2-img span').eq(a).html("<img src='"+array[gnum][$(this).index()-1]+"'>");
            a++;
            if(a==$('#pages2 .inner .p2-img span').length){
                if(str==zhq1[gnum]){
                    gnum++;
                    score++;
                    gsuccess(gnum);
                    setTimeout(function(){
                    show();
                    },3000);
                    jige(score);

                }else{
                    $('#pages2 .inner .p1-img img').attr("src","img/page_level"+(gnum+1)+"_fail.jpg");
                    setTimeout(function(){
                        gnum++;
                        gfail(gnum);
                        setTimeout(function(){
                        show();
                    },4000)
                    },1000)
                }
            }
        })
    }
    show();
    function gsuccess(gnum){
        setTimeout(function(){
            $('#pages4').show();

            $('#pages4 .inner .success h4').eq(0).html(success[gnum-1]);

        },1000)
        setTimeout(function(){
            $('#pages4').hide();
        },3000)

    };
    function gfail(gnum){
        $('#pages2 .inner .p1-img img').attr("src","img/page_level"+(gnum)+"_fail.jpg");
        $('#pages3 .inner .fail h4').eq(0).html(fail[gnum-1]);
        setTimeout(function(){
            $('#pages3').show();

        },1000);
        setTimeout(function(){
            $('#pages3').hide();
        },4000)
    }
    function nextg(gnum){
        if(gnum==5){
            $('#pages2').hide();
            $('#pages5').show();
            return;
        }
        $('#pages2 .inner .p1-img img').attr("src","img/page_level"+(gnum+1)+"_icon.jpg");
        $('#pages2 .inner .p3-img img').attr("src","img/page_level"+(gnum+1)+"_list.jpg");
        if(gnum==0){
            $('#pages2 .inner .p2-img').html("<img class='imgs2' src='img/page_cai_collection2.png'  />"+
            "<span class='sp1'></span>"+
            "<span class='sp2'></span>");
        }else if(gnum==1){
            $('#pages2 .inner .p2-img').html("<img class='imgs2' src='img/page_cai_collection3.png'  />"+
            "<span class='sp3'></span>"+
            "<span class='sp4'></span>"+"<span class='sp5'></span>");
        }else if(gnum==2) {
            $('#pages2 .inner .p2-img').html("<img class='imgs2'src='img/page_cai_collection3.png'  />"+
            "<span class='sp3'></span>"+
            "<span class='sp4'></span>"+"<span class='sp5'></span>");
        }else if(gnum==3) {
            $('#pages2 .inner .p2-img').html("<img class='imgs2'src='img/page_cai_collection4.png'  />"+
            "<span class='sp6'></span>"+
            "<span class='sp7'></span>"+"<span class='sp8'></span>"+"<span class='sp9'></span>");
        }else if(gnum==4) {
            $('#pages2 .inner .p2-img').html("<img class='imgs2'src='img/page_cai_collection4.png'  />"+
            "<span class='sp6'></span>"+
            "<span class='sp7'></span>"+"<span class='sp8'></span>"+"<span class='sp9'></span>");
        }

    }
    function jige(score){
        if(score<=1){
            $('#pages5').css({
                'background': 'url(img/bujinge.jpg)no-repeat',
            });

        }else{
            $('#pages5').css({
                'background':' url(img/page_result_ok_bg.jpg)no-repeat'
            });

        }
        if(score>=5){
            return;
        }

        $("#pages5 .inner .score img").attr('src','img/page_result_bad_'+score+'.png')
        $('#pages5 .inner .restart').click(function(){
            $("#pages5").hide();
            $("#pages2").show();
            gnum=0;
            score=0;
            show();
        })

    }


});
